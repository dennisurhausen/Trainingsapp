# Trainingsplan Wo 1–14 · Version 54

Web-App für deinen Trainingsplan (Stand: Plan v5.1 vom 13.11.2026).

## Neu in Version 54
- Supersätze: jede Übung hat ihr eigenes Gewicht und „Letztes Mal“ (vorher stand bei ①②③ das Gewicht der ersten Übung)
- Übungen ohne Ziel-kg zeigen „zuletzt … kg“; ✓ ohne Eingabe übernimmt das Gewicht vom letzten Mal
- Ein Übungstausch bei einer Supersatz-Übung gilt nur noch für diese Übung (alte Einträge werden korrigiert)
- Sicherer Start: Falls eine Umstellung fehlschlägt, bleiben deine Daten erhalten (plus Sicherung)

## Aus Version 53 (Plan v5.1 vom 13.11.)
- Neuer Plan eingebaut: kein Wettkampf im Januar, Hälften/ganze Übungen bis zur Pause gestrichen, Wo 13–14 Platzhalter bis Plan v6
- Vergangenes bleibt wie geplant: Wo 1–4 Turnen und alle Gym-Einheiten vor dem 13.11. aus dem alten Plan (z. B. Übergrätschen am Do), damit Verlauf und „Plan erfüllt“ stimmen
- Gym: Aufwärmsätze ab Wo 3 („Aufwärmen 1 · Bankdrücken“), grau und kleiner. Ziel-kg = % vom aktuellen Ziel der Hauptübung. Zählen nicht für e1RM, Calc, Load und Statistik
- Schraube: Hilfe-Stufen „Grube Akrobahn“ → „Grube Boden“ → „ohne“. Einträge 26.10.–12.11. mit „Weichboden“ wurden zu „Grube Akrobahn“ (so stand es im Turn-Log der Excel)
- Neu am Di: Schrauben-Drills am Trampolin (Kann, unter Boden)
- Kür-Entscheid und Wettkampf-Countdown entfernt; Kür-Check zeigt „Elemententscheid ca. Mitte März“; neuer Hinweis 10.01.: Plan v6 einspielen
- Gym-Knopf heißt jetzt „Aufwärmen allgemein“
- Plan in der App aktualisieren: Vergangenes bleibt auch dort erhalten

## Aus Version 52
- **Neue Datei vorlage.js – bitte einmal mit hochladen.** Die Excel-Vorlage steckt nicht mehr in index.html, sondern wird erst beim Export geladen. index.html ist dadurch 636 KB statt gut 1 MB (seit v51 lag sie knapp über 1 MB).
- Gym-Grafik zeigt jeden Satz: durchgezogen = schwerer Satz, gestrichelt = Schnitt der leichteren Sätze, Kreise = einzelne Sätze (z. B. Bankdrücken 1 schwer + 3 leicht)
- Beschriftung am Linienende: „schwer 93“, „leicht 83“, „e1RM 114“ (oben kg, unten Wdh)
- Plan-Stand jetzt gepunktet, damit er nicht mit den leichten Sätzen verwechselt wird
- Pause-Wochen (Wo 10–11, Weihnachten) sind in der Grafik grau hinterlegt – dort gibt es keinen Plan-Stand
- Beschriftungen dünner
- Bei normalen Übungen: Linie = bester Satz, Kreise = übrige Sätze; Knopf „Leichte Sätze“ bzw. „Alle Sätze“ blendet sie aus
- Antippen zeigt alle Sätze der Einheit, z. B. „schwer 92,5×6 → e1RM 114 · leicht 82,5×8, 82,5×7, 82,5×6“

## Aus Version 51
- Gym-Log: pro Übung „Dieses Training“ und „Letztes“ nebeneinander (kg | Wdh @RIR), Workload und Veränderung in %, Ø kg/Wdh
- Turnen-Log: bei jeder Übung „zuletzt …“ mit ▲/▼
- Gym-Grafik: feste Achsen ab 0, die sich beim Ein-/Ausblenden von Linien nicht mehr verschieben

## Aus Version 50
- Gym-Statistik: Grafik zeigt pro Einheit Gewicht und e1RM (kg, oben) und Wdh (unten, eigener Streifen) des besten Satzes
- Linien unter der Grafik einzeln ein- und ausblendbar (Gewicht · Wdh · e1RM), gilt für alle Übungen
- Punkt antippen zeigt Datum, Plan, kg × Wdh und e1RM, ohne die Karte auf- oder zuzuklappen; Antippen anderswo klappt wie gewohnt
- Große Zahl = letztes e1RM aus deinen Sätzen, der Kraft-Stand steht daneben

## Aus Version 49
- Einturnen steht wieder zuerst, danach die Geräte in olympischer Reihenfolge (Boden, Pferd, Ringe, Sprung, Barren, Reck), dann Handstand und Kondition

## Aus Version 48
- Geräte überall in olympischer Reihenfolge (Boden, Pferd, Ringe, Sprung, Barren, Reck), danach Handstand, Einturnen, Kondition. Die Reihenfolge im Training bleibt wie im Plan des Abends.

## Aus Version 47
- Turnen-Statistik: bei Auswahl eines Geräts/einer Gruppe nur noch die Elemente, ohne doppelte Kopfzeile
- „Alle Gruppen“: alle Gruppen eingeklappt, auch Schwerpunkte

## Aus Version 46
- Statistik → Turnen: Geräte bzw. Gruppen eingeklappt, Antippen klappt auf
- Filter wie beim Gym: Auswahl nach Gerät/Gruppe oder einzelner Übung, dazu Suche (in beiden Ansichten)
- Kür-Check eingeklappt mit Ampel-Punkten, Antippen zeigt die Details

## Aus Version 45
- Übungs-Kartei mit Reitern Turnen | Gym: alle Turnübungen nach Gerät (Plan, eigene, Zusatz, frei), mit Menge und letztem Datum; eigene Turnübungen anlegen
- Statistik → Turnen → „Alle Übungen · wie oft“: jede Turnübung mit Summe, Anzahl Einheiten und letztem Datum (Gesamt / 4 Wochen / diese Woche)

## Aus Version 44
- Woche: laufende Woche wird mit der Vorwoche bis zum gleichen Tag verglichen; „%-Pkt.“
- Turnen: „ohne Hilfe 4/5 gelungen“ statt Prozent; Kür-Check (wettkampfreif / fast / mit Hilfe / offen, Countdown)
- Hilfe abbauen: ≥ 80 % mit aktueller Hilfe in 3 Einheiten → Vorschlag für die nächste Stufe (im Training mit „Übernehmen“)
- Erste vs. letzte Versuche: Hinweis bei deutlichem Qualitätsabfall
- Session-RPE: nach jeder Einheit Anstrengung 0–10; Belastung & Erholung in der Woche (mit Tagesform)
- Log: Klartext „x % vom Plan · +y % extra“
- Stagnation nur noch in Aufbauwochen und wenn der Plan steigert (keine Fehlalarme mehr bei Sixpack/Entlastung)
- Plan: Zyklus-Grafik standardmäßig nur Blöcke; Kalender zeigt echte geplante Stunden
- Mehr: gruppiert in Mein Plan · Körper · Daten
- Hinweis zum Home-Bildschirm (Datensicherheit in Safari)

## Aus Version 43
- Turnen pro Gerät: jede Übung zählt gleich (Anteil vom eigenen Soll), statt Ausführungen zu zählen
- Kacheln: „Turnen Plan erfüllt“ und „Versuche gelungen“; Sauberkeit-Grafik entfernt

## Aus Version 42
- Einstellungen als aufklappbare Abschnitte mit kurzer Erklärung; Hilfen-Vorlage entfernt
- „Turnen: Hilfen & Rollen“ und „Gym: Maximalkraft-Tests“ (vorher Kraft-Stände)
- Gym-Hauptübungen: nur Grafiken, Antippen zeigt Details
- Notenverlauf heißt „Sauberkeit pro Woche“ mit Erklärung

## Aus Version 41
- Statistik vereinfacht: Woche · Turnen · Gym · Log
- Woche: Wochen wechseln, 4 Kennzahlen, Turnen pro Gerät (Kreise + Balken), max. 5 Hinweise, alle Wochen im Vergleich, Ø Note pro Woche
- Turnen: Elemente mit Zahlen (gelungen, ohne Hilfe, Ø Note); Antippen zeigt Quote pro Woche, Note pro Einheit, Hilfe-Stufen, letzte Einheiten, Notizen
- Einstellungen: Turn-Elemente (Hilfen + Rolle je Element) und Kraft-Stände

## Aus Version 40
- Hilfen pro Element: eigene Auswahl und Reihenfolge (Statistik → Turnen → Element), mit Vorschlägen je Element
- „Kann es mit …“: schwierigste Hilfe-Stufe mit ≥ 70 % Erfolg (mind. 3 Versuche, 28 Tage); Lernstufe richtet sich danach

## Aus Version 39
- Gym-Statistik: bei Plan A/B/C in Plan-Reihenfolge; Übungen standardmäßig zugeklappt, Antippen klappt auf (Grafik + alle Infos); Hauptübungen immer aufgeklappt

## Aus Version 38
- Übersicht: mit ‹ › zwischen Wochen wechseln
- Reiter „Kraft“ heißt jetzt „Gym“
- Lernstufe A/B/C wird automatisch berechnet (Versuche, gelungen, Hilfe-Stufe, Note)
- Link „Reihenfolge der Hilfen ändern“ im Element-Detail

## Aus Version 37
- Statistik neu sortiert: Übersicht · Turnen · Kraft · Wochen · Log
- Übersicht: Woche im Vergleich zur Vorwoche, neue Bestwerte, was gut läuft, was Aufmerksamkeit braucht (Geräte unter Plan, stagnierende Übungen)
- Kraft: Grafiken direkt sichtbar, Auswahl per Liste (Hauptübungen, Plan A/B/C, Alternativen, Alle, einzelne Übung) und Suche; ☆ markiert Hauptübungen; Stagnation wird markiert
- Turnen: Lern-Elemente und alle Übungen in einem Reiter; Element-Detail mit Hilfe-Stufen-Verlauf und Notizen
- Hilfen-Reihenfolge und eigene Hilfen unter Mehr → Einstellungen; Dips-Körpergewicht nur noch dort

## Aus Version 36
- Kraft-Statistik: Übungen nach Plan A/B/C sortiert, plus „Alternativ“ (getauschte und Zusatzübungen) und „Alle“; Suche
- Antippen zeigt Bestwert, Verlauf, Volumen, letzte Einheiten und bei Plan-Übungen die Stände A/B/C
- Hauptübungen frei wählbar (Standard: Beinpresse, Bankdrücken, Latzug)

## Aus Version 35
- Tages-Kreise und Log rechnen beim Turnen gleich (nach Ausführungen): grün = geplante Muss-Ausführungen, orange = alles darüber hinaus (Zusatz, Kann, mehr als Soll)

## Aus Version 34
- Zusatzübungen füllen die Kreise oben (Tage, Geräte, Log) in Orange direkt hinter dem Plan-Anteil; „+“ wenn mehr als das Soll

## Aus Version 33
- Notiz pro Versuch (im Versuch-Editor), sichtbar im Log und im Export; Punkte mit Notiz haben eine kleine Markierung
- Gym: Aufwärmen-Haken nach dem Start, die Aufwärmzeit wird separat gemessen und nicht der ersten Übung zugerechnet

## Aus Version 32
- Bauch 2 (Supersatz) schon am Freitag Woche 2 (30.10.)

## Aus Version 31
- Neuer Plan (Trainingsplan_Wo1-14_v5_1): ab Wo 3 Bauch 1/2 als Supersatz statt Schiffchen/Winkelstütz, Fliegende wieder in Einheit B, neue Zeitschätzungen
- Supersatz: nach jedem Satz geht automatisch die nächste Übung der Runde auf (① → ② → ③ → Pause → ①)
- Alles ist zugeklappt, auch Zuhause; ist eine Übung fertig, geht die nächste automatisch auf (auch bei Versuchen, sobald der letzte Versuch eine Note hat)
- Eingetragene Gym-Sätze, Tausch und Satz-Änderungen bleiben bei geänderter Reihenfolge im Plan an der richtigen Übung
- Pausen in Sekunden („60 s“) starten jetzt den Timer

## Aus Version 30
- Zusatzübungen werden gemerkt: „Wieder dabei?“ schlägt sie mit den letzten Werten vor (Sätze, Wdh, kg), ein Tipp fügt sie hinzu
- Im Formular: zuletzt genutzte Übungen zum Antippen und „Auch für die restlichen Einheiten dieser Woche“

## Aus Version 29
- Dehn-/Halte-Timer: ▶ pro Satz startet den Timer, danach Pause (einstellbar) und der nächste Satz startet automatisch
- Zusatzübungen direkt in der Turn- oder Gym-Einheit, mit Sätzen, Wdh/Sek/Versuchen, kg und RIR, im Log und in der Statistik über den Plan hinaus
- Sprachansagen entfernt
- Gym-Statistik zeigt den Wochen-Load (kg × Wdh in Tonnen) statt Sätze

## Aus Version 4
- Neuer Plan: Satz-Aufteilung (z. B. 3×4) zum Antippen, Landungs-Leiter, neue Reihenfolge, neue Regeln
- Einfacher: fertige Übungen klappen zu, „jetzt“ markiert die nächste Übung, Details unter „⋯ mehr“, Rückgängig-Knopf, Hilfe-Auswahl wie im Turn-Log
- Export: Excel im Format deines Plans (Turn-Log, Gym Plan, Calc, Status, Stufen, Notizen ausgefüllt) plus Blätter App-Auswertung, App-Turnen, App-Gym

## Aktualisieren auf GitHub Pages
Alle Dateien aus diesem Ordner hochladen und die alten ersetzen (auch exceljs.min.js und vorlage.js – beide werden für den Excel-Export gebraucht).
Deine Einträge bleiben erhalten und werden automatisch auf den neuen Plan übertragen.
